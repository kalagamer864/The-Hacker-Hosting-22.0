# Backend
Simple mock backend for The Hacker Hosting.

Install:
```
cd backend
npm install
node server.js
```

The server uses db.json to persist users and servers.
